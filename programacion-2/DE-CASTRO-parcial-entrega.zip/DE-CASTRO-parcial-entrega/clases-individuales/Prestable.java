public interface Prestable {
    void presta(String cliente);
}
