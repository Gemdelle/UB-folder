public class Cliente {
//    01. ATTRIBUTES
    private String nombre;

//    02. CONSTRUCTOR
    public Cliente(String nombre) {
        this.nombre = nombre;
    }

//    03. SETTERS & GETTERS

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
